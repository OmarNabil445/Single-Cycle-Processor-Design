// cpu_top_tb.v
// Testbench for TSP Nearest-Neighbour Solver on RV64I Single-Cycle CPU
// Team 12 - 8 Egyptian Cities
//
// Verifies:
//   - Memory loading of distance matrix
//   - TSP nearest-neighbour computation
//   - Final total distance in x17 and at address 0x300
//   - Correct execution flow (branch behavior, loop iteration)
//
// Expected result: total_distance = 978 (scaled x100)

`timescale 1ns / 1ps

module cpu_top_tb;

    reg         clk;
    reg         rst;
    wire [63:0] pc;
    wire [31:0] instruction;
    wire [63:0] alu_result;
    wire [63:0] write_data;
    wire        branch_taken;

    // ─────────────────────────────────────────────────────────────────────
    // DUT
    // ─────────────────────────────────────────────────────────────────────
    cpu_top DUT (
        .clk(clk),
        .rst(rst),
        .pc_current(pc),
        .instruction(instruction),
        .alu_result(alu_result),
        .write_data(write_data),
        .branch_taken(branch_taken)
    );

    // ─────────────────────────────────────────────────────────────────────
    // Clock Generation - 10 ns period
    // ─────────────────────────────────────────────────────────────────────
    initial clk = 0;
    always #5 clk = ~clk;

    // ─────────────────────────────────────────────────────────────────────
    // Register File Access
    // ─────────────────────────────────────────────────────────────────────
    integer i;
    integer cycle_count;
    reg [63:0] r [0:31];

    task read_regs;
        integer j;
        begin
            for (j = 0; j < 32; j = j + 1)
                r[j] = DUT.RF.registers[j];
        end
    endtask

    task print_regs;
        integer j;
        begin
            $display("");
            $display("  Register File (non-zero):");
            for (j = 0; j < 32; j = j + 1)
                if (r[j] != 64'b0)
                    $display("    x%0d = %0d", j, r[j]);
        end
    endtask

    // ─────────────────────────────────────────────────────────────────────
    // Data Memory Access
    // ─────────────────────────────────────────────────────────────────────
    reg [63:0] mem_val;

    task read_mem;
        input [63:0] addr;
        begin
            mem_val = DUT.DM.mem[addr[12:3]];
        end
    endtask

    // ─────────────────────────────────────────────────────────────────────
    // Verification Helper
    // ─────────────────────────────────────────────────────────────────────
    integer pass_count;
    integer fail_count;

    task check_val;
        input [64*8-1:0] name;
        input [63:0] expected;
        input [63:0] actual;
        begin
            if (expected == actual) begin
                $display("  PASS | %-50s | exp=%0d  got=%0d",
                         name, expected, actual);
                pass_count = pass_count + 1;
            end
            else begin
                $display("  FAIL | %-50s | exp=%0d  got=%0d",
                         name, expected, actual);
                fail_count = fail_count + 1;
            end
        end
    endtask

    // ─────────────────────────────────────────────────────────────────────
    // Simulation Logging
    // ─────────────────────────────────────────────────────────────────────
    reg logging;

    task log_state;
        begin
            if (logging) begin
                $display("  Cycle %3d | PC=0x%04X | instr=0x%08X | alu=0x%016X | br=%b",
                         cycle_count, pc, instruction, alu_result, branch_taken);
            end
        end
    endtask

    // ─────────────────────────────────────────────────────────────────────
    // Stimulus
    // ─────────────────────────────────────────────────────────────────────
    initial begin
        pass_count = 0;
        fail_count = 0;
        cycle_count = 0;
        logging = 0;  // Set to 1 for detailed instruction trace

        $display("================================================================");
        $display("  TSP Nearest-Neighbour Solver - RV64I Single-Cycle CPU");
        $display("  Team 12 - 8 Egyptian Cities");
        $display("  Expected total distance: 978 (scaled x100)");
        $display("================================================================");

        // ── Reset sequence ──
        rst = 1;
        @(posedge clk); #1;
        @(posedge clk); #1;
        rst = 0;
        @(posedge clk); #1;

        $display("");
        $display("  Executing TSP nearest-neighbour solver...");
        $display("  (logging %s)", logging ? "ON" : "OFF");

        // ── Run processor for 1200 cycles ──
        for (i = 0; i < 1200; i = i + 1) begin
            @(posedge clk); #1;
            cycle_count = i + 1;

            log_state();

            // Detect halt (infinite loop at DONE label)
            if (DUT.branch_taken && (DUT.MUX_PC.branch_target == DUT.pc_current)) begin
                $display("");
                $display("  [HALT DETECTED] PC stuck at 0x%04X (DONE loop)", pc);
                i = 1200;  // Exit loop
            end
        end

        // ── Read results ──
        read_regs();
        read_mem(64'h300);

        // ── Verification ──
        $display("");
        $display("================================================================");
        $display("  TSP VERIFICATION RESULTS");
        $display("================================================================");

        $display("");
        $display("  [Route Accumulator]");
        check_val("x17 (total_distance accumulator)", 64'd978, r[17]);

        $display("");
        $display("  [Memory Output]");
        check_val("mem[0x300] (stored total distance)", 64'd978, mem_val);

        // Check key intermediate values
        $display("");
        $display("  [Visit Flags - final state]");
        check_val("visited[0] (El Gouna) should be 1", 64'd1, DUT.DM.mem[64]);
        // All cities should be visited
        for (i = 0; i < 8; i = i + 1) begin
            if (DUT.DM.mem[64 + i] != 1) begin
                $display("  FAIL | visited[%0d] NOT set! got=%0d", i, DUT.DM.mem[64 + i]);
                fail_count = fail_count + 1;
            end
        end

        // ── Register dump ──
        print_regs();

        // ── Data memory dump (relevant area) ──
        $display("");
        $display("  Data Memory (distance matrix verification):");
        $display("    D[0][7] (El Gouna -> Sohag) = %0d (expect 216)", DUT.DM.mem[7]);
        $display("    D[7][6] (Sohag -> Asyut)    = %0d (expect 80)",  DUT.DM.mem[62]);
        $display("    D[6][5] (Asyut -> Minya)     = %0d (expect 100)", DUT.DM.mem[53]);
        $display("    D[5][4] (Minya -> Beni Suef) = %0d (expect 104)", DUT.DM.mem[44]);
        $display("    D[4][3] (Beni Suef->Faiyum)  = %0d (expect 35)",  DUT.DM.mem[35]);
        $display("    D[3][2] (Faiyum -> Giza)     = %0d (expect 79)",  DUT.DM.mem[26]);
        $display("    D[2][1] (Giza -> Cairo)      = %0d (expect 4)",   DUT.DM.mem[17]);
        $display("    D[1][0] (Cairo -> El Gouna)  = %0d (expect 360)", DUT.DM.mem[8]);

        // ── Summary ──
        $display("");
        $display("================================================================");
        if (fail_count == 0)
            $display("  TSP COMPUTATION: ALL TESTS PASSED (%0d/%0d)", pass_count, pass_count);
        else
            $display("  TSP COMPUTATION: %0d PASSED, %0d FAILED", pass_count, fail_count);
        $display("  Total cycles executed: %0d", cycle_count);
        $display("  Final total distance:  %0d (scaled x100)", r[17]);
        $display("  Raw distance:          %0.2f degrees", r[17] / 100.0);
        $display("================================================================");

        $finish;
    end

    // ─────────────────────────────────────────────────────────────────────
    // Waveform Dump
    // ─────────────────────────────────────────────────────────────────────
    initial begin
        $dumpfile("cpu_top_tb.vcd");
        $dumpvars(0, cpu_top_tb);
    end

endmodule
