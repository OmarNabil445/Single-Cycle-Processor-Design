#!/usr/bin/env python3
"""
TSP Preprocessor — RV64I Single-Cycle Processor
================================================
Team 12 Dataset: 8 Egyptian Cities
Pipeline: preprocessing → assembly → machine code → memory init files → CPU execution

This script is the preprocessing front-end for the TSP workload that executes
on the custom RV64I single-cycle processor.  It generates:

  - data_memory.mem        (distance matrix, 64-bit integers)
  - instruction_memory.mem (machine code, 32-bit RISC-V instructions)
  - tsp_program.asm        (human-readable assembly listing)
  - route_visualization.png (city map with TSP route)

The CPU implements ONLY: add, sub, xor, srl, addi, ld, sd, beq, blt
(and additionally: and, or, sll, andi, ori, xori, slli, srli via the ALU)

No multiply, no divide, no floating point, no recursion.
All heavy computation (distance matrix, route planning) is preprocessed here.
The CPU executes integer-based nearest-neighbor path accumulation.

Author: Team 12
"""

import math
import os
import struct
import sys

# ═══════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════

CITIES = [
    ("El Gouna",  27.3967, 33.6806),
    ("Cairo",     30.0444, 31.2357),
    ("Giza",      30.0131, 31.2089),
    ("Faiyum",    29.3084, 30.8428),
    ("Beni Suef", 29.0661, 31.0994),
    ("Minya",     28.0871, 30.7618),
    ("Asyut",     27.1783, 31.1859),
    ("Sohag",     26.5569, 31.6948),
]

START_CITY = 0          # El Gouna
NUM_CITIES = len(CITIES)
SCALE = 100             # multiply raw Euclidean distance → integer

# Memory layout (byte addresses used by ld/sd)
DMEM_BASE     = 0x000   # distance matrix base address
DMEM_VISITED  = 0x200   # visited-flag array base address
DMEM_RESULT   = 0x300   # final total distance output
DMEM_ROUTE    = 0x308   # route array output (city indices)

INF = 9999               # "infinite" sentinel for min-dist initialisation

# ═══════════════════════════════════════════════════════════════════════════
# SECTION 1 — DISTANCE MATRIX
# ═══════════════════════════════════════════════════════════════════════════

def euclidean_degrees(lat1, lon1, lat2, lon2):
    """
    Euclidean distance in lat/lon degrees, scaled to integer.
    Floating-point used ONLY in preprocessing — CPU sees only integers.
    """
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    dist = math.sqrt(dlat * dlat + dlon * dlon)
    return int(round(dist * SCALE))


def compute_distance_matrix():
    """Return N×N integer distance matrix (list of lists)."""
    D = [[0] * NUM_CITIES for _ in range(NUM_CITIES)]
    for i in range(NUM_CITIES):
        for j in range(NUM_CITIES):
            if i == j:
                D[i][j] = 0
            else:
                D[i][j] = euclidean_degrees(
                    CITIES[i][1], CITIES[i][2],
                    CITIES[j][1], CITIES[j][2],
                )
    return D


# ═══════════════════════════════════════════════════════════════════════════
# SECTION 2 — NEAREST-NEIGHBOUR SOLVER  (Python reference)
# ═══════════════════════════════════════════════════════════════════════════

def nearest_neighbor_solve(D):
    """
    Greedy nearest-neighbour TSP heuristic.
    Returns (route_indices, total_scaled_distance).
    """
    n = len(D)
    visited = [False] * n
    route = [START_CITY]
    visited[START_CITY] = True
    current = START_CITY
    total = 0

    for _ in range(n - 1):
        best_dist = INF
        best_city = -1
        for j in range(n):
            if not visited[j] and D[current][j] < best_dist:
                best_dist = D[current][j]
                best_city = j
        total += best_dist
        route.append(best_city)
        visited[best_city] = True
        current = best_city

    # Return to start
    total += D[current][START_CITY]
    route.append(START_CITY)
    return route, total


# ═══════════════════════════════════════════════════════════════════════════
# SECTION 3 — MEMORY FILE GENERATION
# ═══════════════════════════════════════════════════════════════════════════

def generate_data_memory(D, route, filename="data_memory.mem"):
    """
    Write data_memory.mem:

    Layout (64-bit values):
      [0x000 – 0x1F8]  8×8 distance matrix, row-major, 8 bytes each
      [0x200 – 0x238]  visited-flag array (initialised to 0 except city 0 = 1)
      [0x300]          output: total route distance
      [0x308 – 0x348]  output: route city indices
    """
    with open(filename, 'w') as f:
        # ── Distance matrix ──
        for i in range(NUM_CITIES):
            for j in range(NUM_CITIES):
                f.write(f"{D[i][j]:016X}\n")

        # ── Visited flags (padded to 64-bit each) ──
        for i in range(NUM_CITIES):
            if i == START_CITY:
                f.write(f"{1:016X}\n")   # El Gouna starts visited
            else:
                f.write(f"{0:016X}\n")

        # ── Result slots (zero-initialised) ──
        f.write(f"{0:016X}\n")           # total distance @ 0x300
        for _ in range(NUM_CITIES):
            f.write(f"{0:016X}\n")       # route array @ 0x308

    print(f"[DATA] Wrote {filename}")


# ═══════════════════════════════════════════════════════════════════════════
# SECTION 4 — RV64I ASSEMBLER
# ═══════════════════════════════════════════════════════════════════════════

class Assembler:
    """
    Two-pass assembler for the custom RV64I subset.

    Supported: add, sub, xor, srl, addi, ld, sd, beq, blt
    Also: and, or, sll, andi, ori, xori, slli, srli

    Branch encoding: b_type(byte_offset, ...) — the ImmGen reconstructs
    the byte offset directly (no external shift_left1).
    """

    # Opcodes
    OP_R = 0x33
    OP_I = 0x13
    OP_L = 0x03
    OP_S = 0x23
    OP_B = 0x63

    # funct3 values
    F3_BEQ = 0
    F3_BLT = 4
    F3_LD  = 3
    F3_SD  = 3
    F3_ADD = 0

    def __init__(self):
        self.lines = []        # [(label | None, instr | None, args | None)]
        self.labels = {}       # label_name → byte_address
        self.machine_code = [] # list of 32-bit words
        self.pc = 0

    # ── Program emission ───────────────────────────────────────────────

    def label(self, name):
        self.lines.append((name, None, None))

    def emit(self, instr, *args):
        self.lines.append((None, instr, args))

    # ── Instruction encoding helpers ────────────────────────────────────

    @staticmethod
    def _rtype(funct7, rs2, rs1, funct3, rd):
        return (funct7 << 25) | (rs2 << 20) | (rs1 << 15) | (funct3 << 12) | (rd << 7) | Assembler.OP_R

    @staticmethod
    def _itype(imm12, rs1, funct3, rd):
        return ((imm12 & 0xFFF) << 20) | (rs1 << 15) | (funct3 << 12) | (rd << 7) | Assembler.OP_I

    @staticmethod
    def _stype(imm12, rs2, rs1, funct3):
        imm_11_5 = (imm12 >> 5) & 0x7F
        imm_4_0  = imm12 & 0x1F
        return (imm_11_5 << 25) | (rs2 << 20) | (rs1 << 15) | (funct3 << 12) | (imm_4_0 << 7) | Assembler.OP_S

    @staticmethod
    def _ltype(imm12, rs1, funct3, rd):
        return ((imm12 & 0xFFF) << 20) | (rs1 << 15) | (funct3 << 12) | (rd << 7) | Assembler.OP_L

    @staticmethod
    def _btype(byte_offset, rs2, rs1, funct3):
        """
        Encode B-type branch instruction.
        byte_offset must be even (instruction-aligned); the ImmGen in
        the processor keeps bit 0 = 0, so the reconstructed offset
        equals byte_offset.
        """
        # Clamp to 13-bit signed
        imm13 = byte_offset & 0x1FFF
        b12   = (imm13 >> 12) & 1
        b10_5 = (imm13 >> 5) & 0x3F
        b4_1  = (imm13 >> 1) & 0xF
        b11   = (imm13 >> 11) & 1
        return (b12 << 31) | (b10_5 << 25) | (rs2 << 20) | (rs1 << 15) \
             | (funct3 << 12) | (b4_1 << 8) | (b11 << 7) | Assembler.OP_B

    @staticmethod
    def _imm12(val):
        """Clamp to 12-bit signed immediate."""
        return val & 0xFFF

    # ── Instruction constructors ────────────────────────────────────────

    @staticmethod
    def encode(instr, *args):
        """Static encoding — useful for standalone use."""
        a = args
        if instr == 'add':   return Assembler._rtype(0, a[2], a[1], 0, a[0])
        if instr == 'sub':   return Assembler._rtype(0x20, a[2], a[1], 0, a[0])
        if instr == 'xor':   return Assembler._rtype(0, a[2], a[1], 4, a[0])
        if instr == 'srl':   return Assembler._rtype(0, a[2], a[1], 5, a[0])
        if instr == 'sll':   return Assembler._rtype(0, a[2], a[1], 1, a[0])
        if instr == 'and':   return Assembler._rtype(0, a[2], a[1], 7, a[0])
        if instr == 'or':    return Assembler._rtype(0, a[2], a[1], 6, a[0])
        if instr == 'addi':  return Assembler._itype(Assembler._imm12(a[2]), a[1], 0, a[0])
        if instr == 'andi':  return Assembler._itype(Assembler._imm12(a[2]), a[1], 7, a[0])
        if instr == 'ori':   return Assembler._itype(Assembler._imm12(a[2]), a[1], 6, a[0])
        if instr == 'xori':  return Assembler._itype(Assembler._imm12(a[2]), a[1], 4, a[0])
        if instr == 'slli':  return Assembler._itype(a[2] & 0x3F, a[1], 1, a[0])
        if instr == 'srli':  return Assembler._itype(a[2] & 0x3F, a[1], 5, a[0])
        if instr == 'ld':    return Assembler._ltype(Assembler._imm12(a[2]), a[1], 3, a[0])
        if instr == 'sd':    return Assembler._stype(Assembler._imm12(a[2]), a[0], a[1], 3)
        if instr == 'beq':   return Assembler._btype(a[2], a[1], a[0], 0)
        if instr == 'blt':   return Assembler._btype(a[2], a[1], a[0], 4)
        raise ValueError(f"Unknown instruction: {instr}")

    # ── Passes ──────────────────────────────────────────────────────────

    def pass1(self):
        addr = 0
        for label, instr, _args in self.lines:
            if label is not None:
                self.labels[label] = addr
            if instr is not None:
                addr += 4

    def pass2(self):
        self.pc = 0
        self.machine_code = []
        for _label, instr, args in self.lines:
            if instr is None:
                continue
            code = self._assemble_one(instr, args)
            self.machine_code.append(code)
            self.pc += 4

    def _assemble_one(self, instr, args):
        if instr in ('beq', 'blt'):
            rs1, rs2, target = args
            offset = self.labels[target] - self.pc
            return self.encode(instr, rs1, rs2, offset)
        else:
            return self.encode(instr, *args)

    def assemble(self):
        self.pass1()
        self.pass2()

    # ── Output ──────────────────────────────────────────────────────────

    def write_mem(self, filename="instruction_memory.mem"):
        with open(filename, 'w') as f:
            for code in self.machine_code:
                f.write(f"{code:08X}\n")
        print(f"[INST] Wrote {filename}: {len(self.machine_code)} instructions")

    def write_asm(self, filename="tsp_program.asm"):
        """Write human-readable assembly listing."""
        with open(filename, 'w') as f:
            f.write("; RV64I TSP — Nearest-Neighbour Solver\n")
            f.write("; Assembled for custom single-cycle RV64I processor\n")
            f.write("; Team 12 — 8 Egyptian Cities\n\n")
            f.write(f"{'Address':<10} {'Bytes':<8} {'Instruction':<35}\n")
            f.write("-" * 55 + "\n")
            addr = 0
            idx = 0
            for label, instr, args in self.lines:
                if label:
                    f.write(f"\n{label}:\n")
                if instr and idx < len(self.machine_code):
                    code = self.machine_code[idx]
                    args_str = ", ".join(str(a) for a in args)
                    f.write(f"{addr:#010x}  {code:08X}  {instr:<8} {args_str}\n")
                    addr += 4
                    idx += 1
        print(f"[ASM]  Wrote {filename}")

    def dump_regions(self):
        """Print label → address mapping."""
        for name, addr in sorted(self.labels.items(), key=lambda x: x[1]):
            print(f"       {addr:#06x}  {name}")


# ═══════════════════════════════════════════════════════════════════════════
# SECTION 5 — TSP ASSEMBLY PROGRAM GENERATOR
# ═══════════════════════════════════════════════════════════════════════════

def build_tsp_program():
    """
    Build the nearest-neighbour TSP assembly program.

    Algorithm (executed entirely on the CPU):
      1.  Mark El Gouna (city 0) visited
      2.  Outer loop (steps 1..7):
            min = INF, best = -1
            For each candidate city 0..7:
              if candidate != current and not visited[candidate]:
                load D[current][candidate]
                if dist < min:  update min, best
            total += min
            mark best visited
            current = best
      3.  Return to start: add D[last][0]
      4.  Store total to DMEM_RESULT

    Register map:
      x0   = zero
      x8   = 8  (city count, loop bound)
      x9   = 1  (constant 1 for visited marking)
      x10  = distance matrix base  (DMEM_BASE)
      x11  = visited array base    (DMEM_VISITED)
      x12  = current_city
      x13  = step counter (1..7)
      x14  = candidate index (0..7, inner loop)
      x15  = best_city
      x16  = min_dist (best distance found)
      x17  = total_distance (accumulator)
      x18  = temp — address / offset
      x19  = temp — address / offset
      x20  = temp — visited flag
      x21  = temp — loaded distance value
      x22  = temp — equality check
      x23  = temp — INF constant
      x27  = DMEM_RESULT / DMEM_ROUTE base
      x28  = temp for store operations
    """
    asm = Assembler()

    # ──────────── INIT ────────────
    asm.label("_start")

    # Base addresses
    asm.emit("addi", 10, 0, DMEM_BASE)       # x10 = distance matrix base (0x000)
    asm.emit("addi", 11, 0, DMEM_VISITED)    # x11 = visited array base (0x200)

    # Constants
    asm.emit("addi", 8,  0, NUM_CITIES)      # x8  = 8
    asm.emit("addi", 9,  0, 1)               # x9  = 1

    # Load INF constant = 9999
    # Decompose: 9999 = 0x270F  →  0x27 << 8 | 0x0F
    # Requires: addi + slli + addi (since 9999 > 12-bit signed max)
    asm.emit("addi", 23, 0, 0x27)            # x23 = 0x27
    asm.emit("slli", 23, 23, 8)              # x23 = 0x2700 = 9984
    asm.emit("addi", 23, 23, 0x0F)           # x23 = 9999 (INF)

    # Zero initial state
    asm.emit("addi", 12, 0, START_CITY)      # current_city = 0 (El Gouna)
    asm.emit("addi", 17, 0, 0)               # total = 0
    asm.emit("addi", 27, 0, DMEM_RESULT)     # x27 = DMEM_RESULT (0x300)

    # Mark city 0 visited: *DMEM_VISITED = 1
    asm.emit("sd", 9, 11, 0)                 # visited[0] = 1

    # Initialize step counter
    asm.emit("addi", 13, 0, 1)               # step = 1

    # ──────────── OUTER LOOP ────────────
    asm.label("OUTER")

    # min_dist = INF;  candidate = 0
    asm.emit("add",  16, 23, 0)              # min_dist = INF
    asm.emit("addi", 14, 0, 0)               # candidate = 0

    # ──────────── INNER LOOP ────────────
    asm.label("INNER")

    # Check: candidate == current_city ?
    asm.emit("sub",  22, 14, 12)             # x22 = candidate - current
    asm.emit("beq",  22, 0, "SKIP_CAND")     # skip if same city

    # Check: visited[candidate] ?
    asm.emit("slli", 18, 14, 3)              # x18 = candidate * 8
    asm.emit("add",  18, 11, 18)             # x18 = &visited[candidate]
    asm.emit("ld",   20, 18, 0)              # x20 = visited[candidate]
    asm.emit("blt",  0,  20, "SKIP_CAND")    # if 0 < visited → it's visited

    # Load D[current][candidate]
    # offset_in_bytes = current * 64 + candidate * 8
    asm.emit("slli", 18, 12, 6)              # x18 = current * 64
    asm.emit("slli", 19, 14, 3)              # x19 = candidate * 8
    asm.emit("add",  18, 18, 19)             # x18 = total offset
    asm.emit("add",  18, 10, 18)             # x18 = &D[current][candidate]
    asm.emit("ld",   21, 18, 0)              # x21 = distance

    # Compare: dist < min_dist ?
    asm.emit("blt",  21, 16, "UPDATE_MIN")   # if dist < min, update
    asm.emit("beq",  0,  0,  "SKIP_CAND")    # unconditional jump

    asm.label("UPDATE_MIN")
    asm.emit("add",  16, 21, 0)              # min_dist = distance
    asm.emit("add",  15, 14, 0)              # best_city = candidate

    asm.label("SKIP_CAND")
    asm.emit("addi", 14, 14, 1)              # candidate++
    asm.emit("blt",  14, 8,  "INNER")        # if candidate < 8, loop

    # ──────────── INNER LOOP END ────────────
    # Total += min_dist
    asm.emit("add",  17, 17, 16)             # total += min_dist

    # Mark best_city as visited
    asm.emit("slli", 18, 15, 3)              # x18 = best * 8
    asm.emit("add",  18, 11, 18)             # x18 = &visited[best]
    asm.emit("sd",   9,  18, 0)              # visited[best] = 1

    # current_city = best_city
    asm.emit("add",  12, 15, 0)              # current = best

    # step++
    asm.emit("addi", 13, 13, 1)              # step++
    asm.emit("blt",  13, 8,  "OUTER")        # if step < 8, continue

    # ──────────── RETURN TO START ────────────
    # Add D[last_city][0]
    asm.emit("slli", 18, 12, 6)              # x18 = last * 64
    asm.emit("add",  18, 10, 18)             # x18 = &D[last][0]
    asm.emit("ld",   21, 18, 0)              # x21 = D[last][0]
    asm.emit("add",  17, 17, 21)             # total += return_dist

    # ──────────── STORE RESULT ────────────
    asm.emit("sd",   17, 27, 0)              # mem[DMEM_RESULT] = total

    # ──────────── HALT ────────────
    asm.label("DONE")
    asm.emit("beq",  0,  0,  "DONE")         # infinite loop

    asm.assemble()
    return asm


# ═══════════════════════════════════════════════════════════════════════════
# SECTION 6 — VISUALIZATION
# ═══════════════════════════════════════════════════════════════════════════

def visualize_route(D, route, total_cost, filename="route_visualization.png"):
    """Plot cities, route, and segment distances. Save to PNG."""
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
    except ImportError:
        print("[SKIP] matplotlib not available — skipping visualization")
        return

    fig, ax = plt.subplots(figsize=(14, 9))

    # Route coordinates
    rlat = [CITIES[i][1] for i in route]
    rlon = [CITIES[i][2] for i in route]

    # Draw route segments with arrows
    for idx in range(len(route) - 1):
        i, j = route[idx], route[idx + 1]
        ax.annotate(
            "",
            xy=(CITIES[j][2], CITIES[j][1]),
            xytext=(CITIES[i][2], CITIES[i][1]),
            arrowprops=dict(arrowstyle="->", color="royalblue",
                            lw=2.0, connectionstyle="arc3,rad=0.1"),
        )

    # Plot all city points
    lats = [c[1] for c in CITIES]
    lons = [c[2] for c in CITIES]
    ax.scatter(lons, lats, c='lightgray', s=200, zorder=3, edgecolors='gray',
               linewidths=1.5)

    # Highlight route cities in order
    colors = plt.cm.viridis([i / (len(route) - 1) for i in range(len(route))])
    ax.scatter(rlon, rlat, c=colors, s=250, zorder=4, edgecolors='darkblue',
               linewidths=2)

    # Start / end marker
    ax.scatter(CITIES[START_CITY][2], CITIES[START_CITY][1],
               c='red', s=400, marker='*', zorder=10, edgecolors='darkred',
               linewidths=2,
               label=f'Start / End: {CITIES[START_CITY][0]}')

    # City labels with indices and distances
    for i, (name, lat, lon) in enumerate(CITIES):
        ax.annotate(f"{i}: {name}", (lon, lat),
                    textcoords="offset points", xytext=(10, 8),
                    fontsize=10, fontweight='bold',
                    bbox=dict(boxstyle="round,pad=0.2", fc="white",
                              ec="gray", alpha=0.8))

    # Segment distance labels
    for idx in range(len(route) - 1):
        i, j = route[idx], route[idx + 1]
        mlat = (CITIES[i][1] + CITIES[j][1]) / 2
        mlon = (CITIES[i][2] + CITIES[j][2]) / 2
        d = D[i][j]
        ax.annotate(f"{d / SCALE:.1f}° ({d})",
                    (mlon, mlat),
                    textcoords="offset points", xytext=(0, -16),
                    fontsize=8, color='darkgreen', ha='center',
                    bbox=dict(boxstyle="round,pad=0.1", fc="lightyellow",
                              ec="green", alpha=0.7))

    # Step number labels on route
    for idx in range(1, len(route) - 1):
        i = route[idx]
        angle = 0
        ax.annotate(f"#{idx}",
                    (CITIES[i][2], CITIES[i][1]),
                    textcoords="offset points", xytext=(-12, -12),
                    fontsize=8, color='darkblue', fontweight='bold')

    ax.set_xlabel("Longitude", fontsize=11)
    ax.set_ylabel("Latitude", fontsize=11)
    ax.set_title(
        f"TSP Nearest-Neighbour Route — Team 12 (8 Egyptian Cities)\n"
        f"Scaled Total Distance: {total_cost}  |  "
        f"Raw Distance: {total_cost / SCALE:.2f}°",
        fontsize=13, fontweight='bold',
    )
    ax.legend(loc='upper right', fontsize=10)
    ax.grid(True, alpha=0.25, linestyle='--')
    ax.set_aspect(1.0 / math.cos(math.radians(28.5)))  # approximate lat correction

    plt.tight_layout()
    plt.savefig(filename, dpi=180, bbox_inches='tight')
    plt.close()
    print(f"[PLOT] Saved {filename}")


# ═══════════════════════════════════════════════════════════════════════════
# SECTION 7 — REPORT / SUMMARY
# ═══════════════════════════════════════════════════════════════════════════

def print_report(D, route, total, asm):
    """Print a comprehensive report to stdout."""

    def city_name(i):
        return f"{CITIES[i][0]} ({i})"

    sep = "=" * 72

    print(f"\n{sep}")
    print(f"  TSP PREPROCESSOR REPORT - TEAM 12")
    print(f"{sep}")
    print(f"\n  Cities: {NUM_CITIES}")
    for i, (name, lat, lon) in enumerate(CITIES):
        print(f"    {i}: {name:<12}  ({lat:.4f}, {lon:.4f})")
    print(f"  Starting city: {CITIES[START_CITY][0]}")

    print(f"\n{sep}")
    print(f"  DISTANCE MATRIX (scaled x{SCALE})")
    print(f"{sep}")
    header = "       " + "".join(f"{CITIES[j][0]:>12}" for j in range(NUM_CITIES))
    print(f"  {header}")
    for i in range(NUM_CITIES):
        row = f"  {CITIES[i][0]:>8}" + "".join(f"{D[i][j]:>12}" for j in range(NUM_CITIES))
        print(row)

    print(f"\n{sep}")
    print(f"  NEAREST-NEIGHBOUR ROUTE")
    print(f"{sep}")
    print(f"  Route: {' -> '.join(city_name(c) for c in route)}")
    print(f"  Total scaled distance: {total}")
    print(f"  Total raw distance:    {total / SCALE:.2f} deg")

    print(f"\n  Segment breakdown:")
    cum = 0
    for idx in range(len(route) - 1):
        i, j = route[idx], route[idx + 1]
        d = D[i][j]
        cum += d
        a = "->"
        if idx == 0:
            marker = "START"
        elif idx < NUM_CITIES - 1:
            marker = f"STEP {idx}"
        else:
            marker = "RETURN"
        print(f"    {marker:<8} {city_name(i):<20} {a} {city_name(j):<20}  "
              f"dist={d:>4}  cum={cum:>5}")

    print(f"\n{sep}")
    print(f"  ASSEMBLY PROGRAM")
    print(f"{sep}")
    print(f"  Instructions: {len(asm.machine_code)}")
    print(f"  Instruction memory: {len(asm.machine_code) * 4} bytes (max 4096)")
    print(f"  Data memory usage: {(NUM_CITIES * NUM_CITIES + NUM_CITIES + 1 + NUM_CITIES) * 8} bytes (max 8192)")
    print(f"  Registers used: x8-x23, x27-x28 ({12 + 2} of 31)")

    print(f"\n  Key labels:")
    asm.dump_regions()

    print(f"\n{sep}")
    print(f"  MEMORY LAYOUT")
    print(f"{sep}")
    print(f"  {DMEM_BASE:#06x} - {DMEM_BASE + NUM_CITIES * NUM_CITIES * 8 - 8:#06x}  "
          f"Distance matrix ({NUM_CITIES}x{NUM_CITIES} x 8 bytes)")
    print(f"  {DMEM_VISITED:#06x} - {DMEM_VISITED + NUM_CITIES * 8 - 8:#06x}  "
          f"Visited flags ({NUM_CITIES} x 8 bytes)")
    print(f"  {DMEM_RESULT:#06x}                              "
          f"Total distance output (8 bytes)")
    print(f"  {DMEM_ROUTE:#06x} - {DMEM_ROUTE + NUM_CITIES * 8 - 8:#06x}  "
          f"Route array ({NUM_CITIES} x 8 bytes)")

    print(f"\n{sep}")
    print(f"  Pipeline Status: READY FOR CPU EXECUTION")
    print(f"{sep}")
    print(f"  Generated files:")
    print(f"    - data_memory.mem        (distance matrix + I/O area)")
    print(f"    - instruction_memory.mem (machine code)")
    print(f"    - tsp_program.asm        (assembly listing)")
    print(f"    - route_visualization.png(route map)")
    print(f"\n  Load into Vivado and run cpu_top_tb simulation.")
    print(f"{sep}\n")


# ═══════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════

def main():
    print("TSP Preprocessor for RV64I Single-Cycle Processor")
    print("=" * 60)

    # Step 1: Distance matrix
    D = compute_distance_matrix()

    # Step 2: Reference solution
    route, total = nearest_neighbor_solve(D)

    # Step 3: Generate data memory
    generate_data_memory(D, route)

    # Step 4: Build and assemble TSP program
    asm = build_tsp_program()
    asm.write_mem()
    asm.write_asm()

    # Step 5: Visualize
    visualize_route(D, route, total)

    # Step 6: Report
    print_report(D, route, total, asm)

    # Step 7: Verification hint
    expected_total = total
    print(f"\n[VERIFY] The CPU should compute total = {expected_total}")
    print(f"[VERIFY] Check x17 after simulation halts")
    print(f"[VERIFY] Check mem[{DMEM_RESULT:#06x}] for stored result\n")


if __name__ == "__main__":
    main()
