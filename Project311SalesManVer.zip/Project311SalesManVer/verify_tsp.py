#!/usr/bin/env python3
"""
TSP Verification — Python Simulation of RV64I CPU Execution
=============================================================
Verifies that the generated assembly program correctly:
1. Loads distances from data memory
2. Performs nearest-neighbour path selection
3. Accumulates the total route cost
4. Stores the final result

This runs the exact same machine code through a Python-based
CPU simulator and checks the final register state.
"""

import struct
import sys


# ─── Load hex files ────────────────────────────────────────────────────────

def load_mem_32(filename):
    """Load 32-bit hex file, return list of ints."""
    codes = []
    with open(filename) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('/') and not line.startswith(';'):
                codes.append(int(line, 16))
    return codes


def load_mem_64(filename):
    """Load 64-bit hex file, return list of ints."""
    data = []
    with open(filename) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('/') and not line.startswith(';'):
                data.append(int(line, 16))
    return data


# ─── CPU Simulator (minimal RV64I subset) ──────────────────────────────────

class RiscvSim:
    """
    Minimal Python simulator for the custom single-cycle RV64I processor.
    Implements the exact same behaviour as the Verilog design.
    """

    def __init__(self, instr_mem, data_mem):
        self.instr = instr_mem      # list of 32-bit instructions
        self.data = data_mem[:]     # list of 64-bit data values
        self.regs = [0] * 32        # 32 × 64-bit registers
        self.pc = 0                 # current program counter (bytes)
        self.cycles = 0

    def read_reg(self, r):
        return 0 if r == 0 else self.regs[r]

    def write_reg(self, r, val):
        if r != 0:
            self.regs[r] = val & ((1 << 64) - 1)

    def mem_read(self, addr):
        """Read 64-bit value from data memory (8-byte aligned)."""
        idx = (addr >> 3) & 0x3FF  # 10-bit word index
        return self.data[idx]

    def mem_write(self, addr, val):
        idx = (addr >> 3) & 0x3FF
        self.data[idx] = val & ((1 << 64) - 1)

    def sign_extend(self, val, bits):
        """Sign-extend `bits`-bit value to 64 bits."""
        if val >> (bits - 1):
            return val | (~((1 << bits) - 1))
        return val

    def decode_and_execute(self, instr, instr_pc=None):
        """Decode and execute one instruction. Return True if branch taken."""
        opcode = instr & 0x7F
        rd = (instr >> 7) & 0x1F
        funct3 = (instr >> 12) & 0x7
        rs1 = (instr >> 15) & 0x1F
        rs2 = (instr >> 20) & 0x1F
        funct7 = (instr >> 25) & 0x7F

        v_rs1 = self.read_reg(rs1)
        v_rs2 = self.read_reg(rs2)

        branch_taken = False
        result = 0

        if opcode == 0x33:  # R-type
            # funct7[5] = 0x20 indicates SUB
            is_sub = (funct7 & 0x20) and (funct3 == 0)

            if is_sub:
                result = v_rs1 - v_rs2
            elif funct3 == 0:
                result = v_rs1 + v_rs2
            elif funct3 == 7:
                result = v_rs1 & v_rs2
            elif funct3 == 6:
                result = v_rs1 | v_rs2
            elif funct3 == 4:
                result = v_rs1 ^ v_rs2
            elif funct3 == 1:
                shift = v_rs2 & 0x3F
                result = v_rs1 << shift
            elif funct3 == 5:
                shift = v_rs2 & 0x3F
                result = v_rs1 >> shift
            self.write_reg(rd, result)

        elif opcode == 0x13:  # I-type (ALU immediate)
            imm12 = (instr >> 20) & 0xFFF
            imm = self.sign_extend(imm12, 12)

            # slli / srli have funct3 = 1 / 5 and use imm[5:0] as shift
            if funct3 == 1:
                result = v_rs1 << (imm & 0x3F)
            elif funct3 == 5:
                result = v_rs1 >> (imm & 0x3F)
            elif funct3 == 0:
                result = v_rs1 + imm
            elif funct3 == 7:
                result = v_rs1 & imm
            elif funct3 == 6:
                result = v_rs1 | imm
            elif funct3 == 4:
                result = v_rs1 ^ imm
            self.write_reg(rd, result)

        elif opcode == 0x03:  # Load (ld)
            imm12 = (instr >> 20) & 0xFFF
            imm = self.sign_extend(imm12, 12)
            addr = v_rs1 + imm
            result = self.mem_read(addr)
            self.write_reg(rd, result)

        elif opcode == 0x23:  # Store (sd)
            imm12 = ((instr >> 25) << 5) | ((instr >> 7) & 0x1F)
            imm12 = imm12 & 0xFFF
            imm = self.sign_extend(imm12, 12)
            addr = v_rs1 + imm
            self.mem_write(addr, v_rs2)

        elif opcode == 0x63:  # Branch
            # Decode B-type immediate
            b12 = (instr >> 31) & 1
            b10_5 = (instr >> 25) & 0x3F
            b4_1 = (instr >> 8) & 0xF
            b11 = (instr >> 7) & 1
            offset = (b12 << 12) | (b11 << 11) | (b10_5 << 5) | (b4_1 << 1)
            offset = self.sign_extend(offset, 13)

            if funct3 == 0:  # BEQ
                branch_taken = (v_rs1 == v_rs2)
            elif funct3 == 4:  # BLT
                branch_taken = (v_rs1 < v_rs2)  # signed comparison

            if branch_taken:
                self.pc = (instr_pc if instr_pc is not None else self.pc - 4) + offset

        result = result & ((1 << 64) - 1)
        return branch_taken


    def run(self, max_cycles=2000, trace=False):
        """Run simulation until halt (PC stops changing) or max cycles."""
        prev_pc = -1
        while self.cycles < max_cycles:
            if self.pc == prev_pc:
                if trace:
                    print(f"  [HALT] PC={self.pc:#x} - stopped")
                break

            instr_idx = self.pc >> 2
            if instr_idx >= len(self.instr):
                print(f"  [ERROR] PC={self.pc:#x} out of instruction memory!")
                break

            instr = self.instr[instr_idx]
            instr_pc = self.pc
            prev_pc = self.pc
            self.pc += 4

            branch = self.decode_and_execute(instr, instr_pc)

            if trace:
                flag = ' BR' if branch else ''
                opcode = instr & 0x7F
                opnames = {0x33: 'R', 0x13: 'I', 0x03: 'LD', 0x23: 'SD', 0x63: 'B'}
                name = opnames.get(opcode, '?')
                rd = (instr >> 7) & 0x1F
                rs1 = (instr >> 15) & 0x1F
                rs2 = (instr >> 20) & 0x1F
                print(f"  [{self.cycles:4d}] PC={instr_pc:#06x} {name} "
                      f"rd=x{rd} rs1=x{rs1} rs2=x{rs2} instr={instr:08X}{flag}")

            self.cycles += 1

            if branch and self.pc == prev_pc:
                break

        return self.cycles

    def _print_trace(self, instr, idx, branch):
        """Print a single instruction trace line."""
        opcode = instr & 0x7F
        rd = (instr >> 7) & 0x1F
        funct3 = (instr >> 12) & 0x7
        rs1 = (instr >> 15) & 0x1F
        rs2 = (instr >> 20) & 0x1F
        opnames = {0x33: 'R', 0x13: 'I', 0x03: 'LD', 0x23: 'SD', 0x63: 'B'}
        name = opnames.get(opcode, '?')
        flag = ' BR' if branch else ''
        print(f"  [{self.cycles:4d}] PC={self.pc-4:#06x} {name} "
              f"rd=x{rd} rs1=x{rs1} rs2=x{rs2} instr={instr:08X}{flag}")


# ─── Verification ──────────────────────────────────────────────────────────

def verify():
    print("=" * 60)
    print("  TSP CPU SIMULATION VERIFICATION")
    print("=" * 60)

    # Load memory images
    try:
        instr = load_mem_32("instruction_memory.mem")
        data = load_mem_64("data_memory.mem")
        data = data + [0] * (1024 - len(data))
    except FileNotFoundError as e:
        print(f"  [ERROR] Missing file: {e}")
        print("  Run `python tsp_preprocessor.py` first to generate files.")
        return

    print(f"\n  Loaded {len(instr)} instructions")
    print(f"  Loaded {len(data)} data words")

    # Disassemble first few instructions
    print("\n  First 5 instructions:")
    from tsp_preprocessor import Assembler
    for i in range(min(5, len(instr))):
        print(f"    [{i:2d}] 0x{instr[i]:08X}")

    # Create and run simulator
    sim = RiscvSim(instr, data)
    cycles = sim.run(max_cycles=1500)

    print(f"\n  Executed {cycles} cycles")

    # Check results
    print(f"\n  {'=' * 50}")
    print(f"  RESULTS")
    print(f"  {'=' * 50}")

    # Register dump
    print(f"\n  Register File (non-zero):")
    for i in range(32):
        if sim.regs[i] != 0:
            print(f"    x{i:2d} = {sim.regs[i]:>10d}  (0x{sim.regs[i]:016x})")

    # Memory dump — output area
    total_addr_idx = 0x300 >> 3
    mem_total = sim.data[total_addr_idx]
    print(f"\n  Data Memory:")
    print(f"    mem[0x300] (total distance) = {mem_total}")

    # Visited flags
    visited_base = 0x200 >> 3
    visited = [sim.data[visited_base + i] for i in range(8)]
    print(f"    Visited flags: {visited}")

    # Expected results
    from tsp_preprocessor import nearest_neighbor_solve, compute_distance_matrix
    D = compute_distance_matrix()
    _, expected_total = nearest_neighbor_solve(D)

    print(f"\n  {'=' * 50}")
    print(f"  VERIFICATION")
    print(f"  {'=' * 50}")

    all_pass = True

    # Check total distance
    print(f"\n  Total distance:")
    if sim.regs[17] == expected_total:
        print(f"    PASS | x17 = {sim.regs[17]} (expected {expected_total})")
    else:
        print(f"    FAIL | x17 = {sim.regs[17]} (expected {expected_total})")
        all_pass = False

    # Check stored result
    if mem_total == expected_total:
        print(f"    PASS | mem[0x300] = {mem_total} (expected {expected_total})")
    else:
        print(f"    FAIL | mem[0x300] = {mem_total} (expected {expected_total})")
        all_pass = False

    # Check visited
    if all(v == 1 for v in visited):
        print(f"    PASS | All cities visited: {visited}")
    else:
        print(f"    FAIL | Not all visited: {visited}")
        all_pass = False

    # Check visited[0] (El Gouna)
    if visited[0] == 1:
        print(f"    PASS | El Gouna (city 0) marked visited")
    else:
        print(f"    FAIL | El Gouna NOT visited!")
        all_pass = False

    # Summary
    print(f"\n  {'=' * 50}")
    if all_pass:
        print(f"  ALL VERIFICATION CHECKS PASSED")
    else:
        print(f"  SOME CHECKS FAILED — see above")
    print(f"  {'=' * 50}")

    # Print route comparison
    from tsp_preprocessor import nearest_neighbor_solve, CITIES
    route, _ = nearest_neighbor_solve(D)
    print(f"\n  Expected route:")
    print(f"    {' -> '.join(f'{CITIES[c][0]} ({c})' for c in route)}")
    print(f"  Total distance: {expected_total} (scaled x100)")

    return all_pass


if __name__ == "__main__":
    sys.exit(0 if verify() else 1)
