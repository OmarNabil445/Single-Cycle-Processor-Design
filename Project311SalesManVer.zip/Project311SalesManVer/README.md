# TSP Nearest-Neighbour Solver on Custom RV64I Single-Cycle Processor

**Team 12 — 8 Egyptian Cities**  
**Hardware/Software Co-Design Project**

---

## Table of Contents

1. [Architecture Overview](#1-architecture-overview)
2. [Algorithm Explanation](#2-algorithm-explanation)
3. [Hardware/Software Co-Design](#3-hardwaresoftware-co-design)
4. [Memory Organisation](#4-memory-organisation)
5. [Assembly Program](#5-assembly-program)
6. [Simulation & Verification](#6-simulation--verification)
7. [Complexity Discussion](#7-complexity-discussion)
8. [ISA Limitations & Preprocessing Rationale](#8-isa-limitations--preprocessing-rationale)
9. [Results](#9-results)
10. [File Reference](#10-file-reference)

---

## 1. Architecture Overview

### 1.1 The Pipeline

```
┌──────────────────┐
│  Python          │  Preprocessing: coordinate storage, distance
│  Preprocessor    │  calculation (floating-point), integer quantisation,
│  (tsp_preprocessor.py) │  assembly generation, machine code assembly
└──────┬───────────┘
       ↓
┌──────────────────┐
│  Distance Matrix  │  8×8 integer matrix, Euclidean distances ×100
│  Generation       │  → data_memory.mem (64-bit hex entries)
└──────┬───────────┘
       ↓
┌──────────────────┐
│  RISC-V Assembly  │  Nearest-neighbour heuristic: loops, loads,
│  (tsp_program.asm) │  comparisons, accumulation
└──────┬───────────┘
       ↓
┌──────────────────┐
│  Machine Code     │  Two-pass assembler → instruction_memory.mem
│  Generation       │  (32-bit hex entries, RV64I encoding)
└──────┬───────────┘
       ↓
┌──────────────────┐
│  CPU Execution    │  Single-cycle RV64I processor in Verilog
│  (Vivado)         │  Fetches, decodes, executes each instruction
└──────┬───────────┘
       ↓
┌──────────────────┐
│  Simulation +     │  Testbench verification, waveform analysis,
│  Verification     │  pass/fail summary, register dump
└──────────────────┘
```

### 1.2 Processor Datapath (RV64I Subset)

The single-cycle RV64I processor implements a standard RISC-V datapath:

- **Program Counter** — 64-bit register, synchronous reset, loads `pc_next` on every clock edge
- **Instruction Memory** — 4 KB (1024 × 32-bit), word-addressed via `pc[11:2]`, pre-loaded from `instruction_memory.mem`
- **Register File** — 32 × 64-bit, x0 hardwired to zero, synchronous write on posedge clk
- **ALU** — Supports ADD, SUB, AND, OR, XOR, SLL, SRL, SLT via 4-bit control
- **Data Memory** — 8 KB (1024 × 64-bit), pre-loaded distance matrix, synchronous write, asynchronous read
- **Immediate Generator** — Decodes I-type, S-type, B-type immediates from instruction word
- **Control Unit** — Decodes opcode + funct3 + funct7 → generates all datapath control signals
- **Branch Logic** — BEQ (zero flag) and BLT (SLT result = 1) determine branch target

### 1.3 Supported Instructions

| Category | Instructions | Encoding |
|----------|-------------|----------|
| R-type   | `add`, `sub`, `xor`, `srl`, `and`, `or`, `sll` | `opcode=0x33` |
| I-type   | `addi`, `andi`, `ori`, `xori`, `slli`, `srli` | `opcode=0x13` |
| Load     | `ld` | `opcode=0x03` |
| Store    | `sd` | `opcode=0x23` |
| Branch   | `beq`, `blt` | `opcode=0x63` |

**Not supported:** multiply, divide, floating-point, `jal`/`jalr` (no J-type), `bne`/`bge`/`bltu` (partial B-type), `auipc`/`lui` (U-type).

---

## 2. Algorithm Explanation

### 2.1 Nearest-Neighbour Heuristic

The Traveling Salesman Problem (TSP) asks: given a set of cities and pairwise distances, what is the shortest possible route that visits each city exactly once and returns to the origin? TSP is NP-hard — no polynomial-time algorithm is known for the optimal solution.

For this project we implement the **nearest-neighbour (NN) heuristic**, a greedy approximation:

```
1. Start at city 0 (El Gouna)
2. Mark El Gouna as visited
3. For step = 1 to N-1:
   a. Among all unvisited cities, find the one closest to the current city
   b. Add that distance to the total
   c. Mark the chosen city as visited
   d. Set current city = chosen city
4. Add the distance from the last city back to El Gouna
5. Total is the approximate tour length
```

The NN heuristic runs in O(N²) time and typically produces tours within 15–25% of the optimal length. For this dataset of 8 cities, the algorithm makes exactly 7 branching decisions plus the return leg.

### 2.2 Dataset — Team 12 Cities (Egypt)

| # | City | Latitude | Longitude |
|---|------|----------|-----------|
| 0 | El Gouna | 27.3967 | 33.6806 |
| 1 | Cairo | 30.0444 | 31.2357 |
| 2 | Giza | 30.0131 | 31.2089 |
| 3 | Faiyum | 29.3084 | 30.8428 |
| 4 | Beni Suef | 29.0661 | 31.0994 |
| 5 | Minya | 28.0871 | 30.7618 |
| 6 | Asyut | 27.1783 | 31.1859 |
| 7 | Sohag | 26.5569 | 31.6948 |

Starting city: **El Gouna** (city 0)

### 2.3 Computed Route

The nearest-neighbour heuristic produces the following route:

```
El Gouna → Sohag → Asyut → Minya → Beni Suef → Faiyum → Giza → Cairo → El Gouna
```

| Segment | Distance (scaled ×100) | Distance (degrees) |
|---------|----------------------|-------------------|
| El Gouna → Sohag | 216 | 2.16 |
| Sohag → Asyut | 80 | 0.80 |
| Asyut → Minya | 100 | 1.00 |
| Minya → Beni Suef | 104 | 1.04 |
| Beni Suef → Faiyum | 35 | 0.35 |
| Faiyum → Giza | 79 | 0.79 |
| Giza → Cairo | 4 | 0.04 |
| Cairo → El Gouna | 360 | 3.60 |
| **Total** | **978** | **9.78** |

---

## 3. Hardware/Software Co-Design

### 3.1 Division of Labour

| Stage | Where | What |
|-------|-------|------|
| Preprocessing | Python (x86 host) | City coordinates, floating-point Euclidean distance, integer quantisation, assembly generation, machine code assembly |
| Computation | RV64I CPU (Verilog) | Integer loads/stores, arithmetic, comparisons, branching, loop control |
| Verification | Testbench (Verilog) | Register monitoring, memory inspection, pass/fail assertion |

### 3.2 Why This Split?

The custom CPU has severe ISA limitations:

- **No floating-point unit** — distances cannot be computed on the CPU
- **No multiply/divide** — Euclidean distance requires squaring and square root
- **No division** — needed for normalisation
- **No recursion** — the call stack is not supported (no JALR, no stack pointer convention)
- **Limited branch set** — only BEQ and BLT; no BNE, BGE, or other conditional branches

Therefore, all non-integer computation is **preprocessed** in Python, where we:

1. Compute Euclidean distances using IEEE 754 double-precision arithmetic
2. Scale by 100× and round to integers
3. Generate the complete 8×8 distance matrix
4. Write the matrix to `data_memory.mem` for CPU loading
5. Generate the assembly program with correct branch offsets
6. Assemble to machine code

### 3.3 Integer Quantisation Strategy

Raw distances in degrees:

```
d = √((lat₂ − lat₁)² + (lon₂ − lon₁)²)
```

These are floating-point values. To make them CPU-friendly:

```
D_int[i][j] = round(d_float[i][j] × 100)
```

The scaling factor (100) is chosen to preserve two decimal digits of precision while keeping all values within the 64-bit signed integer range. The final accumulated value (978 for the NN tour) fits comfortably in a 64-bit register and can be scaled back to degrees by dividing by 100 (done in post-processing / testbench).

---

## 4. Memory Organisation

### 4.1 Data Memory Layout

```
Address Range     | Contents                     | Size
──────────────────┼──────────────────────────────┼──────
0x0000 – 0x01F8   | Distance matrix [8×8]        | 512 B  (64 × 8 B)
0x0200 – 0x0238   | Visited flags [8]            |  64 B  (8 × 8 B)
0x0240 – 0x02FF   | (reserved)                   | 192 B
0x0300            | Total distance (output)       |   8 B
0x0308 – 0x0340   | Route array (output)          |  64 B  (8 × 8 B)
```

### 4.2 Distance Matrix Addressing

The matrix is stored row-major. Each entry `D[i][j]` is at:

```
address(i,j) = BASE + (i × 8 + j) × 8
```

The assembly program computes this as:

```asm
slli x18, x12, 6       ; current_city × 64  (= ×8 ×8)
slli x19, x14, 3       ; candidate × 8
add  x18, x18, x19     ; total byte offset
add  x18, x10, x18     ; base + offset → final address
ld   x21, 0(x18)       ; load distance
```

### 4.3 Instruction Memory

- Size: 4 KB (1024 × 32-bit words)
- Word address: `pc[11:2]`
- Initialised from `instruction_memory.mem` via `$readmemh`
- Default: all NOPs (`addi x0, x0, 0`)

---

## 5. Assembly Program

### 5.1 Register Allocation

| Register | Purpose |
|----------|---------|
| `x0` | Hardwired zero |
| `x8` | Constant 8 (city count, loop bound) |
| `x9` | Constant 1 (visited marking, increments) |
| `x10` | Distance matrix base address (0x000) |
| `x11` | Visited array base address (0x200) |
| `x12` | `current_city` index |
| `x13` | Outer loop step counter |
| `x14` | Inner loop candidate index |
| `x15` | `best_city` index |
| `x16` | `min_dist` (best distance found) |
| `x17` | `total_distance` accumulator |
| `x18`–`x22` | Temporaries (address calc, loaded values) |
| `x23` | INF sentinel (9999) |
| `x27` | Output base address (0x300) |

### 5.2 Program Structure

```
_start:     (0x0000)  Initialization — base addresses, constants, visited[0]=1
OUTER:      (0x0030)  min_dist=INF, candidate=0
INNER:      (0x0038)  ── inner loop ──
                        skip? (candidate==current_city)
                        skip? (visited[candidate])
                        load D[current][candidate]
                        if (distance < min_dist) → UPDATE_MIN
                        candidate++
                        if (candidate < 8) → INNER
                      ── inner loop end ──
                        total += min_dist
                        mark best_city visited
                        current_city = best_city
                        step++
                        if (step < 8) → OUTER
                        (fall through: all 7 steps done)
                        load D[last_city][0]  (return to start)
                        total += return_dist
                        store total → mem[0x300]
DONE:       (0x00AC)  Infinite loop (halt)
```

### 5.3 Key Assembly Patterns

**Address calculation for distance lookup:**
```asm
slli x18, x12, 6       ; current × 64  (shift by 6 = multiply by 64)
slli x19, x14, 3       ; candidate × 8 (shift by 3 = multiply by 8)
add  x18, x18, x19     ; byte offset from base
add  x18, x10, x18     ; absolute address in data memory
ld   x21, 0(x18)       ; load distance
```

**Minimum-finding idiom:**
```asm
blt  x21, x16, UPDATE_MIN  ; if new < best, update
beq  x0,  x0,  SKIP_CAND   ; else continue (unconditional jump)

UPDATE_MIN:
add  x16, x21, x0          ; min_dist = distance
add  x15, x14, x0          ; best_city = candidate
```

**Loop control (backward branch):**
```asm
addi x14, x14, 1           ; candidate++
blt  x14, x8, INNER        ; if candidate < 8, loop back
```

**Halt idiom (infinite loop):**
```asm
DONE:
beq  x0, x0, DONE          ; branch to self
```

### 5.4 Machine Code Encoding

44 instructions → 176 bytes of instruction memory.  
All branch offsets are verified correct by the two-pass assembler.

---

## 6. Simulation & Verification

### 6.1 Simulation Setup

The testbench (`cpu_top_tb.v`) performs:

1. **Reset** — 2 cycles with `rst=1`, then release
2. **Execution** — Run for up to 1200 clock cycles
3. **Halt detection** — Detect infinite loop (PC stops changing)
4. **Verification** — Check final register values and memory contents
5. **Reporting** — Pass/fail summary with all checks

### 6.2 What Is Verified

| Check | Expected | Source |
|-------|----------|--------|
| `x17` (accumulator) | 978 | Register file read |
| `mem[0x300]` (output) | 978 | Data memory read |
| `visited[0]` (El Gouna) | 1 | Data memory read |
| All visited flags | 1 (all visited) | Data memory read |
| Key distance entries | See report | Pre-loaded matrix |

### 6.3 Waveform Analysis (Vivado)

The simulation dumps a VCD file (`cpu_top_tb.vcd`) for waveform viewing. Key signals to observe:

- **`pc`** — Shows instruction fetch sequencing, branch taken/not-taken
- **`instruction`** — Current instruction word
- **`alu_result`** — Computed results (addresses, SLT outputs)
- **`branch_taken`** — Asserted when branch condition is true
- **Register file evolution** — Watch `x17` (total distance) accumulate
- **Data memory writes** — Observe `MemWrite` strobes for visited flags and result

Expected observable behaviours:

- PC starts at 0x0000, increments by 4 each cycle (sequential)
- `branch_taken` asserts on backward branches (INNER loop, OUTER loop)
- `x17` increases by the selected minimum distance each outer iteration
- After 7 outer iterations, `x17` increases one final time (return to start)
- PC enters the DONE loop and stops moving

---

## 7. Complexity Discussion

### 7.1 Algorithmic Complexity

**Nearest-Neighbour Heuristic:**
- **Time:** O(N²) — for each of N cities, scan all N candidates
- **Space:** O(N²) — distance matrix (pre-loaded), O(N) — visited array
- **Approximation ratio:** No constant bound, but typically ≤ 1.25× optimal on Euclidean instances

**Comparison with brute-force:**  
Full TSP optimisation for N=8 would require (N−1)!/2 = 2520 distinct tours. On the single-cycle CPU at (say) 50 MHz, this would take 2520 × 8 × ~15 instructions × 20 ns ≈ 6 ms. Feasible, but the assembly program would be ~2000× larger and require factorial-loop control structures that the ISA cannot easily express (no recursion, no indirect jumps).

### 7.2 Why Not Full Brute-Force?

| Factor | Constraint |
|--------|-----------|
| **ISA** | No recursion (no JALR stack), no BNE, no multiplication |
| **Program size** | Full enumeration needs 8 nested loops × perm. generation — impractical for 44-instruction budget |
| **Memory** | 2520 tour costs would need ~20 KB of instruction or data memory |
| **Demonstration value** | NN demonstrates all key ISA features (load, store, add, compare, branch) in a clean O(N²) loop |

### 7.3 Pipeline Limitations

- **Single-cycle** — CPI = 1; no pipelining means no hazards to manage, but also lower throughput
- **No bypassing** — Register writes take effect next cycle (already satisfied by single-cycle design)
- **No cache** — Instruction and data memories are single-cycle SRAM

---

## 8. ISA Limitations & Preprocessing Rationale

### 8.1 What the CPU Cannot Do

| Feature | Missing? | Impact |
|---------|----------|--------|
| Floating-point unit | Not implemented | All FP must be preprocessed |
| Integer multiply | Not implemented | Cannot scale raw distance on CPU |
| Integer divide | Not implemented | Cannot normalise or average |
| Compare-and-branch | BNE missing | Must use `sub` + `beq` for inequality |
| Indirect jump (JALR) | Not implemented | No computed goto, no function calls |
| PC-relative addressing | AUIPC missing | Limited position-independent idioms |

### 8.2 Workarounds

| ISA Gap | Workaround |
|---------|-----------|
| No multiply by 64 | `slli rd, rs, 6` (shift left 6 = ×64) |
| No multiply by 8 | `slli rd, rs, 3` (shift left 3 = ×8) |
| No BNE | `sub` + `beq rs, x0` checks for non-zero result |
| No unconditional jump | `beq x0, x0, target` |
| Large immediate > 12 bits | Decompose: `addi` + `slli` + `addi` pattern |
| Pre-loaded distance matrix | Python writes 64-bit integers to `data_memory.mem` |

### 8.3 Preprocessing Was Required Because...

1. **Distance computation requires floating-point Euclidean distance** — the CPU has no FPU
2. **The ISA cannot multiply** — computing `(Δx)² + (Δy)²` requires multiply
3. **The ISA cannot take square roots** — needed for Euclidean norm
4. **Precomputation ensures correctness** — the assembly program is verified against the Python reference
5. **Memory initialisation** — `$readmemh` loads pre-computed data at time 0, avoiding CPU-side initialisation

---

## 9. Results

### 9.1 Route Visualisation

![TSP Route](route_visualization.png)

The visualisation shows:
- All 8 cities with labelled coordinates
- The nearest-neighbour route with directed arrows
- Segment distances labelled along each edge
- Step numbers at each intermediate city
- The start/end city (El Gouna) highlighted with a red star

### 9.2 Verification Results

| Metric | Expected | Actual | Status |
|--------|----------|--------|--------|
| Route segments | 8 | 8 | ✓ |
| Total scaled distance | 978 | 978 | ✓ |
| All cities visited | True | True | ✓ |
| El Gouna visited | True | True | ✓ |
| Instruction count | 44 | 44 | ✓ |
| Data memory usage | 648 B | 648 B | ✓ |

### 9.3 Resource Usage (Estimated)

| Resource | Used | Available |
|----------|------|-----------|
| Instructions | 44 | 1024 |
| Instruction memory | 176 B | 4 KB |
| Data memory | 648 B | 8 KB |
| Registers | 14 | 31 |
| Clock cycles (approx.) | ~200 | ∞ |

---

## 10. File Reference

| File | Purpose |
|------|---------|
| `tsp_preprocessor.py` | Main preprocessing script: distance matrix, assembly generation, machine code assembly, visualisation |
| `tsp_program.asm` | Human-readable RISC-V assembly listing |
| `instruction_memory.mem` | 32-bit hex machine code (CPU instruction memory) |
| `data_memory.mem` | 64-bit hex data (distance matrix + I/O area) |
| `route_visualization.png` | City map with NN route, segment distances, labels |
| `cpu_top_tb.v` | Updated testbench with TSP verification checks |
| `data_memory.v` | Updated data memory with `$readmemh` initialisation |
| `cpu_top.v` | Top-level CPU datapath (unchanged) |
| `instruction_memory.v` | Instruction memory (unchanged) |
| `control_unit.v` | Control unit (unchanged) |
| `alu.v` | ALU (unchanged) |
| `RegisterFile.v` | Register file (unchanged) |
| `ImmGen.v` | Immediate generator (unchanged) |

---

*Team 12 — Computer Architecture Project — RV64I Single-Cycle Processor*  
*Dataset: 8 Egyptian cities along the Nile*  
*Algorithm: Nearest-Neighbour Heuristic for Traveling Salesman Problem*
