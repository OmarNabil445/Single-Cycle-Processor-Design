// data_memory.v
// 64-bit data memory for ld/sd in single-cycle RV64I processor.
// Pre-loaded from data_memory.mem via $readmemh (distance matrix).
// Synchronous write on posedge clk, asynchronous read.
// Address range: 8 KB (1024 x 64-bit)
//
// Memory layout:
//   [0x000 - 0x1F8]  Distance matrix (8x8 x 64-bit), pre-loaded from file
//   [0x200 - 0x238]  Visited flags, pre-loaded (city 0 = 1)
//   [0x300]          Total distance output (written by program)
//   [0x308 - 0x340]  Route array (written by program)

module data_memory (
    input  wire        clk,
    input  wire        rst,
    input  wire        MemRead,
    input  wire        MemWrite,
    input  wire [63:0] address,         // Byte address from ALU (8-byte aligned)
    input  wire [63:0] write_data,      // Data to store (from read_data2)
    output reg  [63:0] read_data        // Data to read (to MemtoReg MUX)
);

    reg [63:0] mem [0:1023];            // 1024 x 64-bit = 8 KB data memory
    integer i;

    wire [9:0] word_index;              // 10-bit word index from byte address

    assign word_index = address[12:3];  // 8-byte aligned, top 10 bits

    // Pre-load distance matrix + visited flags from data_memory.mem
    // Runs once at time 0, before any clock edge
    initial begin
        for (i = 0; i < 1024; i = i + 1)
            mem[i] = 64'b0;
        $readmemh("data_memory.mem", mem);
    end

    always @(posedge clk) begin
        if (rst) begin
            // Only clear the I/O region (visited flags, results).
            // Distance matrix [0x000-0x1F8] is NOT cleared on reset
            // because it is pre-loaded by $readmemh and the initial block
            // already ran before reset.
            for (i = 64; i < 1024; i = i + 1)   // 64 = 0x200 / 8
                mem[i] <= 64'b0;
            // Re-initialize visited[0] = 1 (El Gouna starts visited)
            mem[64] <= 64'd1;
        end else if (MemWrite) begin
            mem[word_index] <= write_data;
        end
    end

    always @(*) begin
        if (MemRead)
            read_data = mem[word_index];
        else
            read_data = 64'b0;
    end

endmodule
